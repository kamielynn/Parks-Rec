'use strict';

// Development specific configuration
// ==================================
module.exports = {
  // MongoDB connection options
  mongo: {
    uri: 'mongodb://wonderwomen:wonderwomen@ds049631.mongolab.com:49631/wonderwomentech'
  },

  seedDB: true
};